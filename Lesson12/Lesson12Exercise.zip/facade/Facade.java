package facade;

import java.util.Arrays;

/**
 * Kodeskelet til VOP eksamen F15, opgave 2.
 * @author erso
 */
public class Facade
{
    

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Facade facade = new Facade();

//        System.out.println("fillArray: " + Arrays.toString(facade.fillArray(20, 10)));
//        int divisor = 3;
//        System.out.println("Divisors of " + divisor + " has Sum: " + facade.sumOfDivisors(divisor));
//
//        System.out.println("fillUnique: " + Arrays.toString(facade.fillUniqueArray(20, 30)));
//
//        System.out.println("Error: " + Arrays.toString(facade.fillUniquiArray(20, 20)));

    }


}
